#Don't be a thief by stealing other's Hardwork, it took time and effort to make this repo.
#Respect my work by not making any changes here.
import os

START_TEXT = "Hey there, I'm 𝙸𝚜𝚊𝚋𝚎𝚕𝚕𝚊 𝚂𝚞𝚌𝚑𝚒🌹, A video compressor robot.\nI have many more features also😌, just send a video file in my chat to know about them😁."

FORCE_SUB_TEXT = "In order to use this bot, you've to join my parent channel."

CHANNEL_LINK = "https://t.me/DroneBots"

SUPPORT_LINK = "https://t.me/isabella_support"

info_text = "This bot is developed by @MaheshChauhan\n\nWritten in python library TELETHON.\n\nBot by : @DroneBots\nSupport : @TeamDrone\n\nV1.4"   

help_text = """**v1.4**

•`Encode` - encode your video into different lib format or resolution

•`HEVC compress` - negligible loss compression

•`FAST compress` - Very fast and Efficient compression

•`Convert` - change formats or extract audio of any video

•`Rename` - rename any file, extension not required

•`SSHOTS` - generate 10 screenshots of your video

•`Trim` - cut your videos"""

source_text = "**Deploy your own bot**"

DEV = "https://t.me/MaheshChauhan"

spam_notice = "This bot is hosted on heroku, and hence can just run one process at a time.Spamming the bot or encoding adult videos will lead you to a ban."

JPG = "isa.jpg"

JPG0 = 'isa.jpg'

JPG2 = "isa.jpg"

JPG3 = "isa.jpg"

JPG4 = "isa.jpg"

